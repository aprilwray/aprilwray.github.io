/* Helix ribbon hero. Ported from the 21st.dev React component to plain JS.
   Markup lives in the page; this file lays out the 3D ribbon and drives it
   from scroll position. No dependencies, no build step. */
(function () {
  'use strict';

  var root = document.querySelector('.hrh-root');
  if (!root) return;

  var stage = root.querySelector('.hrh-stage');
  var view = root.querySelector('.hrh-view');
  var group = root.querySelector('.hrh-group');
  var screw = root.querySelector('.hrh-screw');
  var l1 = root.querySelector('[data-line="1"]');
  var l2 = root.querySelector('[data-line="2"]');
  var port = root.querySelector('.hrh-port');
  var countEl = root.querySelector('.hrh-count');
  var foot = root.querySelector('.hrh-foot');
  var grid = root.querySelector('.hrh-grid');
  var nav = root.querySelector('.hrh-nav');
  if (!stage || !view || !group || !screw || !l1 || !l2 || !port || !countEl || !foot || !grid) return;

  var ribbonData = [];
  var dataEl = document.getElementById('hero-ribbon');
  if (dataEl) { try { ribbonData = JSON.parse(dataEl.textContent); } catch (e) { ribbonData = []; } }
  if (!ribbonData.length) return;

  var HELIX = { perTurn: 7, slices: 4, pitch: 1.34, tiltZ: -17, tiltX: -9 };
  var PHASE = {
    bio: [0, 0.06],
    split: [0.08, 0.36],
    helix: [0.02, 0.62],
    grid: [0.53, 0.63],
    gridStagger: 0.026,
    gridScroll: [0.8, 1],
    calmOut: [0.04, 0.2],
    calmIn: [0.42, 0.58]
  };

  var clamp01 = function (v) { return v < 0 ? 0 : v > 1 ? 1 : v; };
  var seg = function (p, a, b) { return clamp01((p - a) / (b - a)); };
  var easeInOut = function (t) { return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; };
  var easeOut = function (t) { return 1 - Math.pow(1 - t, 3); };
  var easeSine = function (t) { return 0.5 - 0.5 * Math.cos(Math.PI * t); };
  var px = function (v) { return v.toFixed(2) + 'px'; };

  var reduced = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);

  /* --- letters of the headline, each its own span so they can rise in turn --- */
  function letters(el, delay0) {
    var text = el.getAttribute('data-text') || el.textContent;
    el.textContent = '';
    var leadLen = parseInt(el.getAttribute('data-lead-length') || '0', 10);
    var leadWrap = null;
    if (leadLen) {
      leadWrap = document.createElement('span');
      leadWrap.setAttribute('data-lead', '');
      leadWrap.style.display = 'inline-block';
      el.appendChild(leadWrap);
    }
    Array.prototype.forEach.call(text, function (c, i) {
      var s = document.createElement('span');
      s.className = 'hrh-ch';
      s.style.animationDelay = (delay0 + i * 0.045) + 's';
      if (c === ' ') {
        var sp = document.createElement('span');
        sp.style.display = 'inline-block';
        sp.style.width = '0.12em';
        s.appendChild(sp);
      } else {
        s.textContent = c;
      }
      (leadWrap && i < leadLen ? leadWrap : el).appendChild(s);
    });
  }
  letters(l1, 0.08);
  letters(l2, 0.3);

  /* --- the ribbon: every card is cut into slices, two faces each --- */
  var ribbon = ribbonData.slice(0, 12).reverse();
  var S = HELIX.slices;
  var frag = document.createDocumentFragment();
  ribbon.forEach(function (src) {
    for (var j = 0; j < S * 2; j++) {
      var d = document.createElement('div');
      d.className = 'hrh-slice';
      d.style.backgroundImage = 'url("' + src + '")';
      frag.appendChild(d);
    }
  });
  screw.appendChild(frag);

  var slices = Array.prototype.slice.call(screw.children);
  var cards = Array.prototype.slice.call(grid.children);
  var n = ribbon.length;

  var L = {
    W: 0, H: 0, R: 0, cw: 0, ch: 0, pitch: 0, dTheta: 0, persp: 0, zHead: 0,
    cols: 3, slot: [], tw: 0, th: 0, gridH: 0, top: 0, g: 0
  };

  function layout() {
    var W = stage.clientWidth;
    var H = stage.clientHeight;
    if (!W || !H) return;
    L.W = W; L.H = H;
    var mobile = W < 720;
    var g = parseFloat(getComputedStyle(foot).paddingLeft) || 24;
    L.g = g;

    var U = Math.max(Math.min(W, H * 1.6), H * 0.62);
    L.cw = U * 0.4;
    L.ch = L.cw / 1.5;
    L.dTheta = (Math.PI * 2) / HELIX.perTurn;
    L.R = L.cw / L.dTheta;
    L.pitch = L.ch * HELIX.pitch;
    L.persp = U * 1.05;
    view.style.perspective = px(L.persp);

    var sw = 2 * L.R * Math.sin(L.dTheta / S / 2);
    var dy = (L.pitch * (L.dTheta / S)) / (Math.PI * 2);
    var skew = (Math.atan2(dy, sw) * 180) / Math.PI;
    for (var k = 0; k < slices.length; k++) {
      var back = k % 2;
      var i = Math.floor(k / (2 * S));
      var j = Math.floor(k / 2) % S;
      var a = i * L.dTheta + (j + 0.5) * (L.dTheta / S);
      var y = -(L.pitch * a) / (Math.PI * 2);
      var el = slices[k];
      el.style.width = px(sw + 2);
      el.style.height = px(L.ch);
      el.style.backgroundSize = px(sw * S) + ' ' + px(L.ch);
      el.style.backgroundPosition = px(1 - (back ? S - 1 - j : j) * sw) + ' 0px';
      el.style.transform =
        'rotateY(' + ((a * 180) / Math.PI).toFixed(3) + 'deg) translate3d(' +
        px(-sw / 2 - 1) + ',' + px(y - L.ch / 2 + dy / 2) + ',' + px(L.R) +
        ') skewY(' + (-skew).toFixed(3) + 'deg)' +
        (back ? ' translateX(' + px(sw + 2) + ') rotateY(180deg)' : '');
    }

    L.zHead = -L.R * 0.45;
    var s = L.persp / (L.persp - L.zHead);
    l1.style.fontSize = '100px';
    l2.style.fontSize = '100px';
    var w1 = l1.offsetWidth;
    var w2 = l2.offsetWidth;
    var cap = 0.86;
    var base = 0.925;
    var lead1 = l1.querySelector('[data-lead]');
    var o2 = lead1 ? lead1.offsetWidth / 100 : 0.5;
    var pw = cap * 0.8;
    var gap = 0.06;
    var lg = cap * 0.1;
    var bw = Math.max(w1 / 100 + gap + pw, o2 + w2 / 100);
    var bh = cap * 2 + lg;
    var f = Math.min(((mobile ? 0.9 : 0.8) * W) / bw, ((mobile ? 0.36 : 0.47) * H) / bh);
    var capH = cap * f;
    var left = -(bw * f) / 2 + (mobile ? 0 : W * 0.015);
    var topY = H * (mobile ? -0.08 : -0.06) - (bh * f) / 2;
    var place = function (node, x, capTop) {
      node.style.fontSize = px(f / s);
      node.dataset.x = String(x / s);
      node.dataset.y = String((capTop - base * f + capH) / s);
    };
    place(l1, left, topY);
    place(l2, left + o2 * f, topY + capH + lg * f);
    port.style.width = px((pw * f) / s);
    port.style.height = px(capH / s);
    port.dataset.x = String((left + (w1 / 100 + gap) * f) / s);
    port.dataset.y = String(topY / s);

    var ch = countEl.offsetHeight;
    var baseline2 = topY + capH * 2 + lg * f;
    countEl.style.left = px(W / 2 + left);
    countEl.style.top = mobile ? px(H / 2 + baseline2 + 22) : px(H / 2 + baseline2 - ch);

    var cols = mobile ? 2 : 3;
    var gx = mobile ? 12 : Math.round(g * 0.9);
    var gy = mobile ? 22 : Math.round(g * 1.2);
    var navH = nav ? nav.offsetHeight : 48;
    L.cols = cols;
    L.tw = (W - 2 * g - (cols - 1) * gx) / cols;
    L.th = L.tw / 1.5;
    var capRow = 22;
    var rows = Math.ceil(cards.length / cols);
    L.gridH = rows * (L.th + capRow) + (rows - 1) * gy;
    L.top = navH + (mobile ? 12 : g * 0.6);
    L.slot = cards.map(function (_, idx) {
      return { x: g + (idx % cols) * (L.tw + gx), y: Math.floor(idx / cols) * (L.th + capRow + gy) };
    });
    cards.forEach(function (c) {
      var img = c.firstElementChild;
      img.style.width = px(L.tw);
      img.style.height = px(L.th);
      c.style.width = px(L.tw);
    });
    draw(true);
  }

  var cur = 0;
  var goal = 0;
  var shade = new Float32Array(slices.length).fill(-1);

  function draw(force) {
    var p = cur;
    var W = L.W, H = L.H;
    if (!W) return;
    var calm = reduced;

    var t = easeInOut(seg(p, PHASE.split[0], PHASE.split[1]));
    var gone = t >= 1;
    var out = calm ? 1 - seg(p, PHASE.calmOut[0], PHASE.calmOut[1]) : 1;
    var shift = W * 0.95;
    var z = L.zHead;
    var s = L.persp / (L.persp - z);
    var setHead = function (el, dx) {
      var x = Number(el.dataset.x) + dx / s;
      var y = Number(el.dataset.y);
      el.style.transform = 'translate3d(' + px(x) + ',' + px(y) + ',' + px(z) + ')';
      el.style.opacity = calm ? String(out) : gone ? '0' : '1';
    };
    setHead(l1, calm ? 0 : t * shift);
    setHead(port, calm ? 0 : t * shift);
    setHead(l2, calm ? 0 : -t * shift);

    var bioT = calm ? 1 - out : seg(p, PHASE.bio[0], PHASE.bio[1]);
    foot.style.opacity = String(1 - bioT);
    foot.style.transform = 'translateY(' + px(bioT * 40) + ')';
    var cT = calm ? 1 - out : seg(p, PHASE.split[0], PHASE.split[0] + 0.08);
    countEl.style.opacity = String(1 - cT);
    countEl.style.transform = 'translateX(' + px(-cT * 30) + ')';

    var ht = seg(p, PHASE.helix[0], PHASE.helix[1]);
    var rise = easeSine(ht) * 0.35 + ht * 0.65;
    var spin = -0.85 * Math.PI + ht * 2.1 * Math.PI;
    if (calm || ht <= 0 || ht >= 1) {
      group.style.visibility = 'hidden';
    } else {
      group.style.visibility = 'visible';
      var span = (L.pitch * ((n - 1) * L.dTheta)) / (Math.PI * 2);
      var reach = H / 2 + span / 2 + L.ch * 1.6;
      var y0 = reach - rise * 2 * reach;
      var screwY = -(L.pitch * spin) / (Math.PI * 2);
      var centre = -(span / 2) + screwY;
      group.style.transform =
        'translate3d(' + px(-W * 0.04) + ',' + px(y0 - centre) + ',' + px(-L.R) +
        ') rotateZ(' + HELIX.tiltZ + 'deg) rotateX(' + HELIX.tiltX + 'deg)';
      screw.style.transform = 'rotateY(' + ((spin * 180) / Math.PI).toFixed(3) + 'deg) translateY(' + px(screwY) + ')';
      for (var k = 0; k < slices.length; k++) {
        var i2 = Math.floor(k / (2 * S));
        var j2 = Math.floor(k / 2) % S;
        var a2 = i2 * L.dTheta + (j2 + 0.5) * (L.dTheta / S) + spin;
        var c2 = k % 2 ? -Math.cos(a2) : Math.cos(a2);
        if (c2 < -0.05) continue;
        var b2 = 0.66 + 0.34 * Math.max(0, c2);
        if (force || Math.abs(b2 - shade[k]) > 0.015) {
          shade[k] = b2;
          slices[k].style.filter = 'brightness(' + b2.toFixed(3) + ')';
        }
      }
    }

    var scrollT = easeInOut(seg(p, PHASE.gridScroll[0], PHASE.gridScroll[1]));
    var avail = H - L.top - L.g;
    var landY = H * 0.4;
    var endY = L.gridH <= avail ? L.top + (avail - L.gridH) / 2 : H - L.g - L.gridH;
    var baseY = landY + (endY - landY) * scrollT;
    var anyLanded = false;
    for (var i = 0; i < cards.length; i++) {
      var el = cards[i];
      var slot = L.slot[i];
      var a = PHASE.grid[0] + i * PHASE.gridStagger;
      var ct = calm
        ? seg(p, PHASE.calmIn[0], PHASE.calmIn[1])
        : easeOut(seg(p, a, a + (PHASE.grid[1] - PHASE.grid[0])));
      if (ct <= 0) { el.style.opacity = '0'; continue; }
      if (ct >= 1) anyLanded = true;
      var img = el.firstElementChild;
      var capEl = el.lastElementChild;
      if (calm) {
        el.style.opacity = String(ct);
        el.style.transform = 'translate(' + px(slot.x) + ',' + px(baseY + slot.y) + ')';
        img.style.width = px(L.tw);
        img.style.height = px(L.th);
        capEl.style.opacity = '1';
        continue;
      }
      var k2 = 1 - ct;
      var grow = 1 + 0.4 * k2;
      var w = L.tw * grow;
      var h = L.th * grow;
      var row = Math.floor(i / L.cols);
      var col = i % L.cols;
      var sx = slot.x - (w - L.tw) / 2;
      var sy = baseY + slot.y;
      var fromX = sx;
      var fromY = sy;
      if (row > 0) fromY = H + h * 0.1;
      else if (col === 0) fromX = -w * 1.05;
      else if (col === L.cols - 1) fromX = W + w * 0.05;
      else fromY = -h * 1.05;
      var x2 = sx + (fromX - sx) * k2;
      var y2 = sy + (fromY - sy) * k2;
      img.style.width = px(w);
      img.style.height = px(h);
      el.style.width = px(w);
      el.style.opacity = String(Math.min(1, ct * 3));
      img.style.filter = k2 > 0.01 ? 'blur(' + (k2 * 7).toFixed(2) + 'px)' : '';
      el.style.transform =
        'translate(' + px(x2) + ',' + px(y2) + ') perspective(' + px(L.persp) + ') rotateX(' + (k2 * 16).toFixed(2) + 'deg)';
      capEl.style.opacity = String(seg(ct, 0.8, 1));
    }
    /* once the tiles have landed they are real links again */
    grid.style.pointerEvents = anyLanded ? 'auto' : 'none';
  }

  function target() {
    var r = root.getBoundingClientRect();
    var run = r.height - stage.offsetHeight;
    return run > 0 ? clamp01(-r.top / run) : 0;
  }

  var raf = 0;
  var last = performance.now();
  var visible = true;

  function tick(now) {
    var dt = Math.min(64, now - last);
    last = now;
    goal = target();
    if (reduced) cur = goal;
    else {
      var k = 1 - Math.exp(-dt / 110);
      cur += (goal - cur) * k;
      if (Math.abs(goal - cur) < 0.00005) cur = goal;
    }
    draw();
    raf = visible ? requestAnimationFrame(tick) : 0;
  }

  function start() {
    var io = new IntersectionObserver(function (es) {
      visible = es[es.length - 1].isIntersecting;
      if (visible && !raf) { last = performance.now(); raf = requestAnimationFrame(tick); }
    });
    io.observe(root);
    var ro = new ResizeObserver(function () { layout(); });
    ro.observe(stage);
    layout();
    cur = target();
    draw(true);
    root.setAttribute('data-ready', 'true');
    raf = requestAnimationFrame(tick);
  }

  var started = false;
  var go = function () { if (!started) { started = true; start(); } };
  window.setTimeout(go, 2500);
  if (document.fonts) {
    Promise.all([document.fonts.load('400 100px Anton'), document.fonts.load("700 13px 'Inter Tight'")])
      .catch(function () {})
      .then(go);
  } else {
    go();
  }
})();

# April Wray — portfolio

Static site for [aprilwray.github.io](https://aprilwray.github.io). Plain HTML and CSS, served from the repository root. There is no build step and no JavaScript.

Edit a file, commit it to `main`, and GitHub Pages will publish the change.

## Turn GitHub Pages on

The live site is the root of the `main` branch. A pull request does not update the public site until it is merged.

1. Merge the portfolio pull request into `main`.
2. On GitHub, open the repository **aprilwray/aprilwray.github.io**.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, set **Source** to **Deploy from a branch**.
5. Set **Branch** to `main` and **Folder** to **/ (root)**. Save.
6. Give it a minute. The site will be at <https://aprilwray.github.io/>.

If Pages offers GitHub Actions as the source, choose **Deploy from a branch** instead. There is no install or build command.

Keep the repository name as `aprilwray.github.io`. That name is what publishes the site at the root of `aprilwray.github.io`. Do not add a custom domain unless you have one ready.

## How the files are organised

```
index.html              Home
about.html              About
services.html           Services
contact.html            Contact
work/index.html         Work index. The first card is the featured project.
work/*.html             One page per project
404.html                Missing-page message
assets/css/styles.css   All visual styles. Colours and type are in :root at the top.
assets/fonts/           Self-hosted Fraunces and Source Sans 3
assets/images/          Photographs and screenshots, already resized
favicon.svg             Browser icon
```

## How to edit

- **Words.** Open the `.html` file for that page and change the text. Leave the tags around it.
- **Colours.** In `assets/css/styles.css`, edit the values under `:root`.
- **A photograph or screenshot.** Export a compressed WebP or JPEG, put it in the matching folder under `assets/images/`, and point the `<img src>` at it. Set `width` and `height` to the file's real pixel size.
- **Project order.** Move the card in `work/index.html`, then update the Previous and Next links at the bottom of the project pages.
- **A new project.** Duplicate a file in `work/`, change the words, add a card in `work/index.html`, and add the address to `sitemap.xml`.
- **Navigation and footer.** They are copied into every HTML file.

To preview on your own computer, from the repository folder:

```bash
python3 -m http.server 8000
```

Then open <http://localhost:8000>.

## Still to add

- A contact email on `contact.html` (there is a comment showing where).
- Results, only where there is a source for them.
- Original exports of the smaller design pieces, for sharper images.
